// Function to check if Password and Confirm Password are same
function validatePassword() {
    var password = document.getElementById("pass").value;
    var confirmPassword = document.getElementById("pass1").value;

    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return false;
    }
    return true;
}


// This section is for dissappearing the image when the mouse hovers

document.addEventListener('DOMContentLoaded', () => {
    const image = document.getElementById('my-image');

    image.addEventListener('mouseover', () => {
        image.style.opacity = '0';
    });

    image.addEventListener('mouseout', () => {
        image.style.opacity = '1';
    });
});